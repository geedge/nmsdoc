ipFlag = true;
gateWayFlag = true; 
maskFlag = true; 
macFlag = true;
	//全部选中/或不选
	function allSelect(obj){
 		var b = false;
	    if(obj.checked){
	     b = true;
	    }else{
	     b = false;
	    }
		checkbox = document.all.checkRecords;
		if(checkbox){
			if(checkbox.length){
			size = checkbox.length;
			for(i=0;i<size;i++){
				try{
					checkbox[i].checked=b;
				} catch(ex) {
					;
				} 
			}
			}else{
			 checkbox.checked = b;
			}
		}
	}
	//删除选择记录
	var delMsg = true;
	function delSelectRecords(url){
	if(delMsg){
	 if(!window.confirm("确认删除记录？"))return;
	}
	var b = false;
	 checkbox = document.all.checkRecords;
		size = checkbox.length;
		if(size){
		for(i=0;i<size;i++){
			try{
				if(checkbox[i].checked){
				 b = true;
				 break;
				}
			} catch(ex) {
				;
			} 
		}
		}else{
		 if(checkbox.checked){
		   b = true;
		 }
		}
	 if(!b){
	  alert("请选择要删除的记录!");
	  return;
	 }
	 document.forms(0).action = url;
	 document.forms(0).submit();
	}
	//删除某行记录
	function delRecord(obj,url){
	 if(!window.confirm("确认删除记录？"))return;
	 checkbox = document.all.checkRecords;
		if(checkbox){
			if(checkbox.length){
			size = checkbox.length;
			for(i=0;i<size;i++){
				try{
					checkbox[i].checked=false;
				} catch(ex) {
					;
				} 
			}
			}else{
			 checkbox.checked = false;
			}
		}
	 
	 delMsg = false;
	 var checkObj = obj.parentElement.parentElement.cells(0).childNodes(1);
	 //alert(obj.parentElement.parentElement.cells(0).childNodes(0).id);
	 checkObj.checked = true;
	 delSelectRecords(url);
	}
	
	 //选择数据/下拉菜单
	function checkSelect(obj,value){
		for(i=0;i<obj.options.length;i++){
			if(obj.options[i].value == value){
				obj.options[i].selected = true;
				break;
			}
		}
	}
	
	// 验证ip是否合法
	function checkIp(data){
  		$(data).parent().find(".ip_error").remove();
  		var inputString = $(data).val();
  		var ip4Match = /^(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])$/;  
  	    var ip6Match = /^\s*((([0-9A-Fa-f]{1,4}:){7}([0-9A-Fa-f]{1,4}|:))|(([0-9A-Fa-f]{1,4}:){6}(:[0-9A-Fa-f]{1,4}|((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){5}(((:[0-9A-Fa-f]{1,4}){1,2})|:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){4}(((:[0-9A-Fa-f]{1,4}){1,3})|((:[0-9A-Fa-f]{1,4})?:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){3}(((:[0-9A-Fa-f]{1,4}){1,4})|((:[0-9A-Fa-f]{1,4}){0,2}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){2}(((:[0-9A-Fa-f]{1,4}){1,5})|((:[0-9A-Fa-f]{1,4}){0,3}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){1}(((:[0-9A-Fa-f]{1,4}){1,6})|((:[0-9A-Fa-f]{1,4}){0,4}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(:(((:[0-9A-Fa-f]{1,4}){1,7})|((:[0-9A-Fa-f]{1,4}){0,5}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:)))(%.+)?\s*$/;
  	   
  	    if (!inputString) {
  	    	$(data).parent().append("<span class='help-inline ip_error' style='color:red'>×</span>")
  	    	ipFlag = false;
			return;
		}
		var ip4flag = inputString.match(ip4Match);
		var ip6flag = inputString.match(ip6Match);
		if (ip4flag) {
			ipFlag = true;
		} else if (ip6flag) {
			ipFlag = true;
		} else {
			$(data).parent().append("<span class='help-inline ip_error' style='color:red'>×</span>")
			ipFlag = false;
		}
	}
	
	// 校验网关
	function checkGateway(data, flag) {
		  $(data).parent().find(".gateway_error").remove();
		  var static_gw = $(data).val();
		  
		  if (!static_gw && flag == 0) {
			  gateWayFlag = true;
			  return;
		  }
		  if (!static_gw) {
			  $(data).parent().append("<span class='help-inline gateway_error' style='color:red'>×</span>")
			  gateWayFlag = false;
			  return;  
		  }	  
		  var gatewayMatch = /^(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])$/;
		  var gatewayflag = static_gw.match(gatewayMatch);

		 if (gatewayflag) {
			gateWayFlag = true;
		 } else {
			$(data).parent().append("<span class='help-inline gateway_error' style='color:red'>×</span>")
			gateWayFlag = false;
		 }  

	}
	
	//校验掩码
	function checkMask(data, flag) {
		$(data).parent().find('.mask_success').remove();
		$(data).parent().find('.mask_error').remove();
		var mask = $(data).val();
		var maskMatch = /^(254|252|248|240|224|192|128|0)\.0\.0\.0|255\.(254|252|248|240|224|192|128|0)\.0\.0|255\.255\.(254|252|248|240|224|192|128|0)\.0|255\.255\.255\.(254|252|248|240|224|192|128|0)$/; 
		if (!mask && flag == 0) {
			maskFlag = true;
			return;
		}
		if (!mask) {	
			$(data).parent().append("<span class='help-inline mask_error' style='color:red'>×</span>")
			maskFlag = false;
			return;
		}
	    
		var maskflag = mask.match(maskMatch);
		if (maskflag) {
			maskFlag = true;
		} else {
			$(data).parent().append("<span class='help-inline mask_error' style='color:red'>×</span>")
			maskFlag = false;
		}
	}
	
	//校验mac
	function checkMac(data, flag) {
		$(data).parent().find(".mac_error").remove();
		$(data).parent().find(".mac_success").remove();
		var inputString = $(data).val();
		var macMatch1 = /^[A-Fa-f0-9]{2}:[A-Fa-f0-9]{2}:[A-Fa-f0-9]{2}:[A-Fa-f0-9]{2}:[A-Fa-f0-9]{2}:[A-Fa-f0-9]{2}$/;
		var macMatch2 = /^[A-Fa-f0-9]{2}-[A-Fa-f0-9]{2}-[A-Fa-f0-9]{2}-[A-Fa-f0-9]{2}-[A-Fa-f0-9]{2}-[A-Fa-f0-9]{2}$/;
		if (!inputString && flag == 0) {
			macFlag = true;
			return;
		}
		if (!inputString) {
			$(data).parent().append("<span class='help-inline mac_error' style='color:red'>×</span>")
			macFlag = false;
			return;
		}
		
	    var mac1 = new Array();
	    mac1 = inputString.split(":");
	    var mac2 =new Array();
		mac2 = inputString.split("-");
	    if(!(mac1.length == 6||mac2.length==6)){
			$(data).parent().append("<span  class='help-inline mac_error' style='color:red'>×</span>")
			macFlag = false;
			return;
	    }
	    
		var macflag1 = inputString.match(macMatch1);
		var macflag2 = inputString.match(macMatch2);
		if(macflag1) {
			macFlag = true
		} else if (macflag2){
			macFlag = true
		}else{
			$(data).parent().append("<span class='help-inline mac_error' style='color:red'>×</span>")
			macFlag = false;
		}
	}