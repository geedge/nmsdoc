#!/bin/sh
source /etc/profile
basePath=$(cd `dirname $0`; pwd)

cd ${basePath}
while read line;do
        eval "$line"
done < config
 
src_dir=${src_dir}"/collector/result/*.csv" # 远程服务器文件所在目录
dest_dir=${dest_dir}"/collector/remote_result/"

index=1
flag=1
while [ $flag -eq 1 ]; do
        key='ip'${index}
        value=`eval echo '$'${key}`

	OLD_IFS="$IFS"
        IFS=","
        value_arr=($value)
        IFS=$OLD_IFS
	
	ip=${value_arr[0]}
	username=${value_arr[1]}
	password=${value_arr[2]}

        if [ -z ${value} ]
                then
                        flag=0
                else
			if [ ! -d "$dest_dir/$ip" ];then
				mkdir -p "$dest_dir/$ip"
			fi
#			echo "$ip $username $password $src_dir \"$dest_dir/$ip\""
                        ./expect_scp "$ip" "$username" "$password" "$src_dir" "$dest_dir/$ip/"
                        let "index++"
        fi
done
